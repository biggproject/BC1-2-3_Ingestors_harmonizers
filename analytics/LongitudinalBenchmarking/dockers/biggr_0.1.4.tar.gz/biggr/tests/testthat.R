library(biggr)
library(testthat)

test_check("biggr")
