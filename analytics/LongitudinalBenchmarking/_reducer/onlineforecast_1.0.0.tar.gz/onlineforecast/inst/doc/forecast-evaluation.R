## ---- echo=1:2, purl=1:2------------------------------------------------------
# Load the package
library(onlineforecast)
#library(devtools)
#load_all(as.package("../../onlineforecast"))

## -----------------------------------------------------------------------------
# Keep the data in D to simplify notation
D <- Dbuilding
# Keep the model output in y (just easier code later)
D$y <- D$heatload
# Generate time of day in a forecast matrix
D$tday <- make_tday(D$t, 0:36)

