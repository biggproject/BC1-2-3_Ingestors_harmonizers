#' @title Simple wrapper for paste0().
#' @param ... Passed to paste0().
#' @export

pst <- function(...) {
    paste0(...)
}
